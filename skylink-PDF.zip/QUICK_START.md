# Quick Start Guide
## Aerospace Compliance Validation System

### 🚀 Try the Demo (No API Key Required)
```bash
python demo_validation.py
```

This will generate:
- `demo_compliance_report.html` - Beautiful HTML report
- `demo_compliance_report.txt` - Plain text summary  
- `demo_compliance_result.json` - JSON output for integration

### 📋 Real Validation (Requires OpenAI API Key)

1. **Set your OpenAI API key:**
   ```bash
   set OPENAI_API_KEY=your_key_here
   ```

2. **Run validation on your PDF:**
   ```bash
   python main.py              # Convert PDF to markdown
   python run_validation.py    # Run AI validation
   ```

### 🎯 What You Get

**JSON Output Format:**
```json
{
  "part_number": "MS20470AD4-5.5",
  "serial_number": "224019C462", 
  "purchase_order": "154748",
  "cert_type": "Material Certificate",
  "status": "SOFT_FAIL",
  "confidence_score": 0.82,
  "flags": [
    {
      "issue": "Missing explicit expiration date for Material Certification",
      "reference": "ASA Standard 21.302(b)", 
      "severity": "HIGH"
    }
  ]
}
```

### ✅ Core Validation Rules

1. **Certificate Expiration** - Checks for expired or expiring certificates
2. **Part Number Consistency** - Validates format and consistency across document
3. **Traceability Chain** - Ensures complete documentation chain
4. **ASA Compliance** - AI-powered check against aviation standards
5. **QC Manual Requirements** - Internal quality control validation

### 📊 Status Levels
- **PASS** - No issues found
- **SOFT_FAIL** - Minor issues that need attention
- **HARD_FAIL** - Critical issues requiring immediate action

### 🔧 Installation
If needed, run the installer:
```bash
python install.py
```

### 📖 Full Documentation
See `README.md` for complete documentation and configuration options.