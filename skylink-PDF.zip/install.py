#!/usr/bin/env python3
"""
Installation script for Aerospace Compliance Validation System
"""

import os
import sys
import subprocess
import platform

def run_command(command, description=""):
    """Run a command and handle errors"""
    print(f"🔧 {description}" if description else f"Running: {command}")
    
    try:
        result = subprocess.run(command, shell=True, check=True, capture_output=True, text=True)
        if result.stdout:
            print(f"✅ {result.stdout.strip()}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Error: {e}")
        if e.stderr:
            print(f"Error details: {e.stderr}")
        return False

def check_python_version():
    """Check if Python version is 3.8+"""
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"❌ Python 3.8+ required. Current version: {version.major}.{version.minor}")
        return False
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} detected")
    return True

def setup_virtual_environment():
    """Setup virtual environment if it doesn't exist"""
    if os.path.exists('venv'):
        print("✅ Virtual environment already exists")
        return True
    
    print("🔧 Creating virtual environment...")
    return run_command("python -m venv venv", "Creating virtual environment")

def install_dependencies():
    """Install required dependencies"""
    system = platform.system()
    
    if system == "Windows":
        activate_cmd = "venv\\Scripts\\activate.ps1"
        pip_cmd = f"{activate_cmd} && pip install openai python-dotenv tenacity"
    else:
        activate_cmd = "source venv/bin/activate"
        pip_cmd = f"{activate_cmd} && pip install openai python-dotenv tenacity"
    
    print("🔧 Installing dependencies...")
    return run_command(pip_cmd, "Installing Python packages")

def create_env_template():
    """Create environment file template"""
    env_content = """# Aerospace Compliance Validation System Configuration
# Copy this file to .env and set your actual API key

# OpenAI API Configuration (Required)
OPENAI_API_KEY=your_openai_api_key_here

# Optional: Specify OpenAI model to use (default: gpt-4)
OPENAI_MODEL=gpt-4

# Optional: Set API base URL if using different endpoint
# OPENAI_BASE_URL=https://api.openai.com/v1
"""
    
    try:
        with open('.env.template', 'w') as f:
            f.write(env_content)
        print("✅ Created .env.template file")
        return True
    except Exception as e:
        print(f"❌ Error creating .env.template: {e}")
        return False

def print_next_steps():
    """Print next steps for the user"""
    print("\n" + "="*60)
    print("🎉 INSTALLATION COMPLETE!")
    print("="*60)
    
    print("\n📋 Next Steps:")
    print("1. Get your OpenAI API key from: https://platform.openai.com/api-keys")
    print("2. Set your API key:")
    
    system = platform.system()
    if system == "Windows":
        print("   Windows: set OPENAI_API_KEY=your_key_here")
    else:
        print("   Linux/Mac: export OPENAI_API_KEY=your_key_here")
    
    print("   Or copy .env.template to .env and edit it")
    
    print("\n🚀 Usage:")
    print("1. Generate markdown from PDF:")
    print("   python main.py")
    print("\n2. Run compliance validation:")
    print("   python run_validation.py")
    print("\n3. Or try the demo (no API key needed):")
    print("   python demo_validation.py")
    
    print("\n📖 For more information, see README.md")

def main():
    """Main installation function"""
    print("🔬 Aerospace Compliance Validation System")
    print("📦 Installation Script")
    print("="*50)
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Setup virtual environment
    if not setup_virtual_environment():
        print("❌ Failed to setup virtual environment")
        sys.exit(1)
    
    # Install dependencies
    if not install_dependencies():
        print("❌ Failed to install dependencies")
        sys.exit(1)
    
    # Create environment template
    create_env_template()
    
    # Print next steps
    print_next_steps()

if __name__ == "__main__":
    main() 