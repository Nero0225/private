# Aerospace Compliance Validation System

An AI-powered system for validating aerospace trace documents against ASA standards and internal QC manual requirements.

## Features

- 🤖 **AI-Powered Analysis**: Uses OpenAI GPT-4 to intelligently parse and validate aerospace documents
- 📋 **Comprehensive Validation**: Implements multiple validation rules including:
  - Certificate expiration checking
  - Part number consistency validation
  - Traceability chain verification
  - ASA standards compliance
  - Internal QC manual requirements
- 📊 **Multiple Output Formats**: Generates HTML, text, and JSON reports
- 🎯 **Configurable Rules**: Easily customizable validation rules and severity levels
- 📈 **Confidence Scoring**: Provides confidence scores for validation results

## Core Validation Rules

### 1. Certificate Expiration Validation
- Checks for expired certificates (CRITICAL)
- Warns for certificates expiring within 30 days (MEDIUM)
- Validates date formats and missing expiration dates

### 2. Part Number Consistency
- Validates part number format against aerospace standards
- Checks for consistency across document sections
- Identifies multiple conflicting part numbers

### 3. Traceability Chain Validation
- Ensures complete traceability documentation
- Validates manufacturer information and CAGE codes
- Checks for required lot/serial numbers and material sources

## Installation & Setup

### Prerequisites
- Python 3.8+
- OpenAI API key
- Virtual environment (already created as `venv`)

### Dependencies
```bash
# Activate virtual environment
venv\Scripts\activate.ps1  # Windows PowerShell
# or
source venv/bin/activate   # Linux/Mac

# Install dependencies (already installed)
pip install openai python-dotenv
```

### Configuration
Set your OpenAI API key as an environment variable:

**Windows:**
```cmd
set OPENAI_API_KEY=your_openai_api_key_here
```

**Linux/Mac:**
```bash
export OPENAI_API_KEY=your_openai_api_key_here
```

**Or create a .env file:**
```
OPENAI_API_KEY=your_openai_api_key_here
```

## Usage

### Step 1: Generate Markdown from PDF
First, use the existing PDF parser to convert your trace document:
```bash
python main.py
```
This creates `output.md` from your PDF file.

### Step 2: Run Compliance Validation
```bash
python run_validation.py
```

Or run the validator directly:
```bash
python compliance_validator.py
```

### Output Files Generated
- `compliance_report.html` - Human-readable HTML report
- `compliance_report.txt` - Plain text summary
- `compliance_result.json` - Structured JSON output

## JSON Output Format

```json
{
  "part_number": "MS20470AD4-5.5",
  "serial_number": "224019C462",
  "purchase_order": "154748",
  "cert_type": "Certificate of Conformity",
  "status": "SOFT_FAIL",
  "confidence_score": 0.85,
  "flags": [
    {
      "issue": "Missing expiration date for Form 1 certificate",
      "reference": "ASA Standard 21.302(b)",
      "severity": "HIGH"
    }
  ],
  "extracted_data": {
    "part_numbers": ["MS20470AD4-5.5"],
    "purchase_orders": ["154748"],
    "certificates": [...],
    "manufacturer": {...}
  },
  "generated_at": "2024-01-15T10:30:00"
}
```

## Validation Status Levels

- **PASS**: No compliance issues found
- **SOFT_FAIL**: Minor to moderate issues that may need attention
- **HARD_FAIL**: Critical issues that require immediate action

## Severity Levels

- **LOW**: Minor formatting or documentation issues
- **MEDIUM**: Moderate compliance concerns
- **HIGH**: Significant compliance violations
- **CRITICAL**: Serious violations requiring immediate action

## Configuration

The system is highly configurable through `config.py`:

### Validation Rules
Enable/disable specific validation rules and set severity levels:
```python
VALIDATION_RULES = {
    "certificate_expiration": {
        "enabled": True,
        "warning_days": 30,
        "severity": "CRITICAL"
    },
    # ... more rules
}
```

### ASA Standards References
Customize which ASA standards to check against:
```python
ASA_STANDARDS = {
    "part_21": "ASA Part 21 - Certification procedures",
    "part_145": "ASA Part 145 - Approved maintenance organizations",
    # ... more standards
}
```

### QC Manual Requirements
Define your internal QC requirements:
```python
QC_MANUAL_REQUIREMENTS = {
    "certificate_types": ["Certificate of Conformity", "Form 1"],
    "required_data": ["part_number", "manufacturer", "lot_number"],
    # ... more requirements
}
```

## Supported Document Types

The system can analyze various aerospace trace documents including:
- Material Certificates of Conformity
- EASA Form 1 certificates
- FAA Form 8130-3 certificates
- Boeing Distribution Services documentation
- Manufacturer certifications
- Packing slips with traceability data

## Troubleshooting

### Common Issues

1. **OpenAI API Key Error**
   - Ensure your API key is correctly set
   - Verify you have sufficient credits
   - Check internet connectivity

2. **File Not Found Error**
   - Ensure `output.md` exists in the current directory
   - Run `main.py` first to generate the markdown file

3. **Validation Errors**
   - Check document formatting
   - Verify the document contains required aerospace information
   - Review confidence scores for data extraction quality

### Debug Mode
Enable verbose logging by setting:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## Example Workflow

1. **Document Preparation**
   ```bash
   # Convert PDF to markdown
   python main.py
   ```

2. **Run Validation**
   ```bash
   # Set API key
   set OPENAI_API_KEY=your_key_here
   
   # Run validation
   python run_validation.py
   ```

3. **Review Results**
   - Open `compliance_report.html` in your browser
   - Check `compliance_result.json` for integration with other systems
   - Review flagged issues and take corrective action

## Integration

The JSON output format makes it easy to integrate with:
- Quality management systems
- Document management systems
- Compliance tracking databases
- Workflow automation tools

## Extending the System

### Adding Custom Validation Rules
1. Create a new validation method in `ComplianceValidator`
2. Add the rule to the configuration
3. Update the main validation loop

### Custom Report Formats
1. Extend the `ReportGenerator` class
2. Add new output methods
3. Configure in `REPORT_CONFIG`

## Security Considerations

- API keys are handled securely through environment variables
- No sensitive document data is permanently stored
- OpenAI API calls are made over HTTPS
- Generated reports can be stored in secure locations

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review configuration settings
3. Verify input document format
4. Check OpenAI API status and credits

---

**Note**: This system is designed for aerospace compliance validation. Ensure all regulatory requirements are met for your specific use case and jurisdiction. 