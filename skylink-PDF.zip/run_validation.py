#!/usr/bin/env python3
"""
Simple runner script for Aerospace Compliance Validation System
"""

import os
import sys
from compliance_validator import main as run_validation
from config import validate_config

def setup_environment():
    """Setup and validate the environment"""
    print("Aerospace Compliance Validation System")
    print("=" * 50)
    
    # Check if OpenAI API key is set
    if not os.getenv('OPENAI_API_KEY'):
        print("\n❌ OpenAI API key not found!")
        print("\nTo set your OpenAI API key:")
        print("1. Windows: set OPENAI_API_KEY=your_key_here")
        print("2. Linux/Mac: export OPENAI_API_KEY=your_key_here")
        print("3. Or create a .env file with: OPENAI_API_KEY=your_key_here")
        print("\nGet your API key from: https://platform.openai.com/api-keys")
        return False
    
    # Check if input file exists
    if not os.path.exists('output.md'):
        print("\n❌ Input file 'output.md' not found!")
        print("\nPlease ensure you have:")
        print("1. Run main.py to generate output.md from your PDF")
        print("2. Or place your markdown trace document as 'output.md'")
        return False
    
    print("✅ Environment validation passed")
    return True

def main():
    """Main entry point"""
    if not setup_environment():
        sys.exit(1)
    
    try:
        print("\n🔍 Starting compliance validation...")
        run_validation()
        print("\n✅ Validation completed successfully!")
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Validation interrupted by user")
        sys.exit(1)
        
    except Exception as e:
        print(f"\n❌ Error during validation: {e}")
        print("\nPlease check:")
        print("1. OpenAI API key is valid and has credits")
        print("2. Internet connection is available")
        print("3. Input file format is correct")
        sys.exit(1)

if __name__ == "__main__":
    main() 