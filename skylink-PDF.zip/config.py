"""
Configuration file for Aerospace Compliance Validation System
"""

import os
from typing import Dict, List

# OpenAI Configuration
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
OPENAI_MODEL = os.getenv('OPENAI_MODEL', 'gpt-4')
OPENAI_BASE_URL = os.getenv('OPENAI_BASE_URL', 'https://api.openai.com/v1')

# ASA Standards References
ASA_STANDARDS = {
    "part_21": "ASA Part 21 - Certification procedures for products and parts",
    "part_145": "ASA Part 145 - Approved maintenance organizations", 
    "part_147": "ASA Part 147 - Aviation maintenance technician schools",
    "material_cert": "ASA Standard 21.605 - Material certification requirements",
    "traceability": "ASA Standard 21.137 - Traceability requirements"
}

# QC Manual Requirements
QC_MANUAL_REQUIREMENTS = {
    "certificate_types": [
        "Certificate of Conformity",
        "Material Certificate", 
        "Form 1",
        "Form 8130-3"
    ],
    "required_data": [
        "part_number",
        "manufacturer",
        "lot_number", 
        "material_specification",
        "inspection_records"
    ],
    "expiration_warning_days": 30
}

# Validation Rules Configuration
VALIDATION_RULES = {
    "certificate_expiration": {
        "enabled": True,
        "warning_days": 30,
        "severity": "CRITICAL"
    },
    "part_number_validation": {
        "enabled": True,
        "format_check": True,
        "consistency_check": True,
        "severity": "HIGH"
    },
    "traceability_validation": {
        "enabled": True,
        "required_elements": ["manufacturer", "lot_number", "material_source"],
        "severity": "HIGH"
    },
    "asa_compliance": {
        "enabled": True,
        "severity": "MEDIUM"
    },
    "qc_manual_compliance": {
        "enabled": True,
        "severity": "MEDIUM"
    }
}

# Report Configuration
REPORT_CONFIG = {
    "html_template": "compliance_report.html",
    "text_template": "compliance_report.txt", 
    "json_output": "compliance_result.json",
    "include_raw_data": True,
    "include_confidence_score": True
}

# Severity Levels
SEVERITY_LEVELS = {
    "LOW": 1,
    "MEDIUM": 2, 
    "HIGH": 3,
    "CRITICAL": 4
}

# Part Number Format Patterns
PART_NUMBER_PATTERNS = [
    r'^MS\d+[A-Z]*\d*-\d+.*',  # Military Standard pattern
    r'^NAS\d+[A-Z]*\d*-\d+.*', # National Aerospace Standard
    r'^AN\d+[A-Z]*\d*-\d+.*',  # Army-Navy pattern
    r'^[A-Z]{2,4}\d{3,8}[A-Z]*\d*.*'  # General aerospace pattern
]

def get_config() -> Dict:
    """Get complete configuration dictionary"""
    return {
        "openai": {
            "api_key": OPENAI_API_KEY,
            "model": OPENAI_MODEL,
            "base_url": OPENAI_BASE_URL
        },
        "asa_standards": ASA_STANDARDS,
        "qc_manual": QC_MANUAL_REQUIREMENTS,
        "validation_rules": VALIDATION_RULES,
        "report_config": REPORT_CONFIG,
        "severity_levels": SEVERITY_LEVELS,
        "part_number_patterns": PART_NUMBER_PATTERNS
    }

def validate_config() -> bool:
    """Validate configuration settings"""
    if not OPENAI_API_KEY:
        print("Warning: OPENAI_API_KEY not set. Please set your OpenAI API key.")
        return False
    
    return True 