import os
import json
import re
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from openai import OpenAI
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class ValidationFlag:
    """Represents a compliance validation issue"""
    issue: str
    reference: str
    severity: str = "MEDIUM"  # LOW, MEDIUM, HIGH, CRITICAL

@dataclass
class ComplianceResult:
    """Main compliance validation result"""
    part_number: str
    serial_number: Optional[str]
    purchase_order: Optional[str]
    cert_type: str
    status: str  # PASS, SOFT_FAIL, HARD_FAIL
    flags: List[ValidationFlag]
    extracted_data: Dict[str, Any]
    confidence_score: float

class DocumentParser:
    """Handles document parsing and data extraction using OpenAI"""
    
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
    
    def extract_structured_data(self, markdown_content: str) -> Dict[str, Any]:
        """Extract structured data from markdown using OpenAI"""
        
        extraction_prompt = """
        You are an expert aerospace compliance inspector. Analyze the following aerospace trace document and extract key information.
        
        Extract the following information from the document:
        1. Part numbers (all variations found)
        2. Purchase order numbers
        3. Serial numbers or lot numbers
        4. Certificate types (Form 1, Certificate of Conformity, etc.)
        5. Dates (manufacturing, certification, expiration if any)
        6. Manufacturer information
        7. Material specifications
        8. Quality certifications
        9. Traceability information
        10. Any compliance statements or references
        
        Return the data in the following JSON format:
        {
            "part_numbers": ["list of part numbers"],
            "purchase_orders": ["list of PO numbers"],
            "serial_numbers": ["list of serial/lot numbers"],
            "certificates": [
                {
                    "type": "certificate type",
                    "number": "cert number if available",
                    "date": "YYYY-MM-DD format if available",
                    "issuer": "issuing authority"
                }
            ],
            "dates": {
                "manufacturing": "YYYY-MM-DD",
                "certification": "YYYY-MM-DD",
                "expiration": "YYYY-MM-DD"
            },
            "manufacturer": {
                "name": "manufacturer name",
                "cage_code": "CAGE code if available",
                "approval_number": "approval number if available"
            },
            "specifications": ["list of specifications referenced"],
            "compliance_statements": ["any compliance declarations"],
            "traceability_chain": ["documented traceability path"]
        }
        
        Document to analyze:
        """
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert aerospace compliance inspector specializing in trace document analysis."},
                    {"role": "user", "content": f"{extraction_prompt}\n\n{markdown_content}"}
                ],
                temperature=0.1
            )
            
            # Parse the JSON response
            extracted_text = response.choices[0].message.content
            # Find JSON in the response
            json_start = extracted_text.find('{')
            json_end = extracted_text.rfind('}') + 1
            
            if json_start != -1 and json_end != -1:
                json_str = extracted_text[json_start:json_end]
                return json.loads(json_str)
            else:
                logger.warning("No valid JSON found in OpenAI response")
                return {}
                
        except Exception as e:
            logger.error(f"Error extracting data with OpenAI: {e}")
            return {}

class ComplianceValidator:
    """Handles compliance validation against ASA standards and QC manual"""
    
    def __init__(self, api_key: str):
        self.parser = DocumentParser(api_key)
        self.client = OpenAI(api_key=api_key)
    
    def validate_document(self, markdown_content: str) -> ComplianceResult:
        """Main validation function"""
        
        # Extract structured data
        extracted_data = self.parser.extract_structured_data(markdown_content)
        
        # Initialize validation result
        flags = []
        
        # Run validation rules
        flags.extend(self._validate_certificate_expiration(extracted_data))
        flags.extend(self._validate_part_number_match(extracted_data))
        flags.extend(self._validate_traceability_chain(extracted_data))
        flags.extend(self._validate_asa_compliance(extracted_data, markdown_content))
        flags.extend(self._validate_qc_manual_requirements(extracted_data, markdown_content))
        
        # Determine overall status
        status = self._determine_status(flags)
        
        # Calculate confidence score
        confidence_score = self._calculate_confidence(extracted_data, flags)
        
        # Get primary part number and serial
        part_number = extracted_data.get('part_numbers', ['UNKNOWN'])[0] if extracted_data.get('part_numbers') else 'UNKNOWN'
        serial_number = extracted_data.get('serial_numbers', [None])[0] if extracted_data.get('serial_numbers') else None
        purchase_order = extracted_data.get('purchase_orders', [None])[0] if extracted_data.get('purchase_orders') else None
        cert_type = self._determine_cert_type(extracted_data)
        
        return ComplianceResult(
            part_number=part_number,
            serial_number=serial_number,
            purchase_order=purchase_order,
            cert_type=cert_type,
            status=status,
            flags=flags,
            extracted_data=extracted_data,
            confidence_score=confidence_score
        )
    
    def _validate_certificate_expiration(self, data: Dict[str, Any]) -> List[ValidationFlag]:
        """Validate certificate expiration dates"""
        flags = []
        
        dates = data.get('dates', {})
        expiration_date = dates.get('expiration')
        
        if expiration_date:
            try:
                exp_date = datetime.strptime(expiration_date, '%Y-%m-%d')
                if exp_date < datetime.now():
                    flags.append(ValidationFlag(
                        issue=f"Certificate expired on {expiration_date}",
                        reference="ASA Standard 145.109(a)",
                        severity="CRITICAL"
                    ))
                elif exp_date < datetime.now() + timedelta(days=30):
                    flags.append(ValidationFlag(
                        issue=f"Certificate expiring soon ({expiration_date})",
                        reference="QC Manual Section 3.1",
                        severity="MEDIUM"
                    ))
            except ValueError:
                flags.append(ValidationFlag(
                    issue="Invalid or unreadable expiration date format",
                    reference="QC Manual Section 3.2",
                    severity="MEDIUM"
                ))
        else:
            # Check if this type of document should have an expiration
            certificates = data.get('certificates', [])
            if any('Form 1' in cert.get('type', '') for cert in certificates):
                flags.append(ValidationFlag(
                    issue="Missing expiration date for Form 1 certificate",
                    reference="ASA Standard 21.302(b)",
                    severity="HIGH"
                ))
        
        return flags
    
    def _validate_part_number_match(self, data: Dict[str, Any]) -> List[ValidationFlag]:
        """Validate part number consistency across document"""
        flags = []
        
        part_numbers = data.get('part_numbers', [])
        if not part_numbers:
            flags.append(ValidationFlag(
                issue="No part numbers found in document",
                reference="QC Manual Section 2.1",
                severity="CRITICAL"
            ))
            return flags
        
        # Check for part number consistency
        unique_base_parts = set()
        for part in part_numbers:
            # Remove common variations like revision codes
            base_part = re.sub(r'[-_]\d+$', '', part.strip())
            unique_base_parts.add(base_part)
        
        if len(unique_base_parts) > 1:
            flags.append(ValidationFlag(
                issue=f"Multiple different part numbers found: {', '.join(part_numbers)}",
                reference="QC Manual Section 2.3",
                severity="HIGH"
            ))
        
        # Check part number format compliance
        for part in part_numbers:
            if not self._validate_part_number_format(part):
                flags.append(ValidationFlag(
                    issue=f"Part number {part} does not meet standard format requirements",
                    reference="ASA Standard 21.605",
                    severity="MEDIUM"
                ))
        
        return flags
    
    def _validate_traceability_chain(self, data: Dict[str, Any]) -> List[ValidationFlag]:
        """Validate traceability documentation"""
        flags = []
        
        traceability = data.get('traceability_chain', [])
        manufacturer = data.get('manufacturer', {})
        
        # Check for complete traceability chain
        required_elements = ['manufacturer', 'lot_number', 'material_source']
        missing_elements = []
        
        if not manufacturer.get('name'):
            missing_elements.append('manufacturer identification')
        
        if not data.get('serial_numbers'):
            missing_elements.append('lot/serial number')
        
        if not any('material' in item.lower() for item in traceability):
            missing_elements.append('material source documentation')
        
        if missing_elements:
            flags.append(ValidationFlag(
                issue=f"Incomplete traceability chain - missing: {', '.join(missing_elements)}",
                reference="QC Manual Section 4.1",
                severity="HIGH"
            ))
        
        # Check for CAGE code if manufacturer present
        if manufacturer.get('name') and not manufacturer.get('cage_code'):
            flags.append(ValidationFlag(
                issue="Missing CAGE code for manufacturer",
                reference="ASA Standard 21.137(c)",
                severity="MEDIUM"
            ))
        
        return flags
    
    def _validate_asa_compliance(self, data: Dict[str, Any], content: str) -> List[ValidationFlag]:
        """Validate ASA (Aviation Safety Agency) compliance using AI analysis"""
        flags = []
        
        asa_prompt = f"""
        As an ASA compliance expert, analyze this aerospace trace document for compliance violations.
        
        Check for the following ASA requirements:
        1. Part 21 - Certification procedures for products and parts
        2. Part 145 - Approved maintenance organizations
        3. Material certification requirements
        4. Traceability requirements
        5. Documentation standards
        
        Extracted data: {json.dumps(data, indent=2)}
        
        Identify any specific ASA compliance issues and reference the exact regulation.
        Format your response as a JSON array of issues:
        [
            {{
                "issue": "description of the issue",
                "reference": "ASA Part XX.XXX",
                "severity": "LOW|MEDIUM|HIGH|CRITICAL"
            }}
        ]
        """
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an ASA compliance expert specializing in aviation regulations."},
                    {"role": "user", "content": asa_prompt}
                ],
                temperature=0.1
            )
            
            response_text = response.choices[0].message.content
            # Extract JSON array
            json_start = response_text.find('[')
            json_end = response_text.rfind(']') + 1
            
            if json_start != -1 and json_end != -1:
                json_str = response_text[json_start:json_end]
                issues = json.loads(json_str)
                
                for issue in issues:
                    flags.append(ValidationFlag(
                        issue=issue.get('issue', 'Unknown ASA compliance issue'),
                        reference=issue.get('reference', 'ASA Standard'),
                        severity=issue.get('severity', 'MEDIUM')
                    ))
            
        except Exception as e:
            logger.error(f"Error in ASA compliance validation: {e}")
            flags.append(ValidationFlag(
                issue="Unable to complete ASA compliance check",
                reference="System Error",
                severity="LOW"
            ))
        
        return flags
    
    def _validate_qc_manual_requirements(self, data: Dict[str, Any], content: str) -> List[ValidationFlag]:
        """Validate against internal QC manual requirements"""
        flags = []
        
        # Example QC manual requirements
        certificates = data.get('certificates', [])
        
        # Check for required certificate types
        cert_types = [cert.get('type', '').lower() for cert in certificates]
        
        if not any('conformity' in cert_type for cert_type in cert_types):
            flags.append(ValidationFlag(
                issue="Missing Certificate of Conformity",
                reference="QC Manual Section 5.2",
                severity="HIGH"
            ))
        
        # Check for required specifications
        specifications = data.get('specifications', [])
        if not specifications:
            flags.append(ValidationFlag(
                issue="No technical specifications referenced",
                reference="QC Manual Section 6.1",
                severity="MEDIUM"
            ))
        
        # Check for inspection records
        if 'inspection' not in content.lower():
            flags.append(ValidationFlag(
                issue="Missing inspection documentation",
                reference="QC Manual Section 7.3",
                severity="MEDIUM"
            ))
        
        return flags
    
    def _validate_part_number_format(self, part_number: str) -> bool:
        """Validate part number format against standards"""
        # Basic format validation - can be customized
        if len(part_number) < 5:
            return False
        
        # Check for valid characters (alphanumeric, hyphens, underscores)
        if not re.match(r'^[A-Z0-9\-_]+$', part_number.upper()):
            return False
        
        return True
    
    def _determine_cert_type(self, data: Dict[str, Any]) -> str:
        """Determine the primary certificate type"""
        certificates = data.get('certificates', [])
        
        if not certificates:
            return "Unknown"
        
        # Priority order for certificate types
        priority_types = ['EASA Form 1', 'FAA Form 8130-3', 'Certificate of Conformity', 'Material Certificate']
        
        for cert in certificates:
            cert_type = cert.get('type', '')
            for priority_type in priority_types:
                if priority_type.lower() in cert_type.lower():
                    return priority_type
        
        return certificates[0].get('type', 'Unknown')
    
    def _determine_status(self, flags: List[ValidationFlag]) -> str:
        """Determine overall compliance status"""
        if not flags:
            return "PASS"
        
        severities = [flag.severity for flag in flags]
        
        if "CRITICAL" in severities:
            return "HARD_FAIL"
        elif "HIGH" in severities:
            return "SOFT_FAIL"
        else:
            return "SOFT_FAIL"
    
    def _calculate_confidence(self, data: Dict[str, Any], flags: List[ValidationFlag]) -> float:
        """Calculate confidence score for the validation"""
        base_score = 1.0
        
        # Reduce confidence based on missing data
        if not data.get('part_numbers'):
            base_score -= 0.3
        if not data.get('certificates'):
            base_score -= 0.2
        if not data.get('manufacturer'):
            base_score -= 0.1
        
        # Reduce confidence based on validation issues
        critical_flags = len([f for f in flags if f.severity == "CRITICAL"])
        high_flags = len([f for f in flags if f.severity == "HIGH"])
        
        base_score -= (critical_flags * 0.2 + high_flags * 0.1)
        
        return max(0.0, min(1.0, base_score))

class ReportGenerator:
    """Generates human-readable reports"""
    
    def generate_html_report(self, result: ComplianceResult) -> str:
        """Generate HTML compliance report"""
        
        status_color = {
            "PASS": "#28a745",
            "SOFT_FAIL": "#ffc107", 
            "HARD_FAIL": "#dc3545"
        }
        
        severity_color = {
            "LOW": "#6c757d",
            "MEDIUM": "#ffc107",
            "HIGH": "#fd7e14",
            "CRITICAL": "#dc3545"
        }
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Aerospace Compliance Validation Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #f8f9fa; padding: 20px; border-radius: 5px; }}
                .status {{ font-weight: bold; font-size: 1.2em; color: {status_color.get(result.status, '#000')}; }}
                .section {{ margin: 20px 0; }}
                .flag {{ padding: 10px; margin: 5px 0; border-left: 4px solid; }}
                .flag.LOW {{ border-color: {severity_color['LOW']}; background-color: #f8f9fa; }}
                .flag.MEDIUM {{ border-color: {severity_color['MEDIUM']}; background-color: #fff3cd; }}
                .flag.HIGH {{ border-color: {severity_color['HIGH']}; background-color: #ffeaa7; }}
                .flag.CRITICAL {{ border-color: {severity_color['CRITICAL']}; background-color: #f8d7da; }}
                .data-table {{ border-collapse: collapse; width: 100%; }}
                .data-table th, .data-table td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                .data-table th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Aerospace Compliance Validation Report</h1>
                <p><strong>Part Number:</strong> {result.part_number}</p>
                <p><strong>Serial/Lot Number:</strong> {result.serial_number or 'N/A'}</p>
                <p><strong>Purchase Order:</strong> {result.purchase_order or 'N/A'}</p>
                <p><strong>Certificate Type:</strong> {result.cert_type}</p>
                <p><strong>Status:</strong> <span class="status">{result.status}</span></p>
                <p><strong>Confidence Score:</strong> {result.confidence_score:.2%}</p>
                <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
            
            <div class="section">
                <h2>Validation Results</h2>
                <p><strong>Total Issues Found:</strong> {len(result.flags)}</p>
        """
        
        if result.flags:
            html += "<h3>Issues and Flags:</h3>"
            for flag in result.flags:
                html += f"""
                <div class="flag {flag.severity}">
                    <strong>[{flag.severity}]</strong> {flag.issue}<br>
                    <small>Reference: {flag.reference}</small>
                </div>
                """
        else:
            html += "<p style='color: green;'>✓ No compliance issues found</p>"
        
        html += """
            </div>
            
            <div class="section">
                <h2>Extracted Data Summary</h2>
                <table class="data-table">
        """
        
        # Add extracted data to table
        for key, value in result.extracted_data.items():
            if isinstance(value, list):
                value_str = ', '.join(str(v) for v in value) if value else 'None'
            elif isinstance(value, dict):
                value_str = json.dumps(value, indent=2) if value else 'None'
            else:
                value_str = str(value) if value else 'None'
            
            html += f"""
                <tr>
                    <th>{key.replace('_', ' ').title()}</th>
                    <td>{value_str}</td>
                </tr>
            """
        
        html += """
                </table>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def generate_text_report(self, result: ComplianceResult) -> str:
        """Generate plain text compliance report"""
        
        report = f"""
AEROSPACE COMPLIANCE VALIDATION REPORT
=====================================

Part Number: {result.part_number}
Serial/Lot Number: {result.serial_number or 'N/A'}
Purchase Order: {result.purchase_order or 'N/A'}
Certificate Type: {result.cert_type}
Status: {result.status}
Confidence Score: {result.confidence_score:.2%}
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

VALIDATION RESULTS
==================
Total Issues Found: {len(result.flags)}

"""
        
        if result.flags:
            report += "Issues and Flags:\n"
            report += "-" * 50 + "\n"
            for i, flag in enumerate(result.flags, 1):
                report += f"{i}. [{flag.severity}] {flag.issue}\n"
                report += f"   Reference: {flag.reference}\n\n"
        else:
            report += "✓ No compliance issues found\n\n"
        
        report += "EXTRACTED DATA SUMMARY\n"
        report += "=" * 22 + "\n"
        
        for key, value in result.extracted_data.items():
            if isinstance(value, list):
                value_str = ', '.join(str(v) for v in value) if value else 'None'
            elif isinstance(value, dict):
                value_str = json.dumps(value, indent=2) if value else 'None'
            else:
                value_str = str(value) if value else 'None'
            
            report += f"{key.replace('_', ' ').title()}: {value_str}\n"
        
        return report

def main():
    """Main function to run compliance validation"""
    
    # Get OpenAI API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable not set")
        return
    
    # Read the markdown document
    try:
        with open('output.md', 'r', encoding='utf-8') as f:
            markdown_content = f.read()
    except FileNotFoundError:
        print("Error: output.md file not found")
        return
    
    # Initialize validator
    validator = ComplianceValidator(api_key)
    
    # Run validation
    print("Running compliance validation...")
    result = validator.validate_document(markdown_content)
    
    # Generate reports
    report_generator = ReportGenerator()
    
    # Generate HTML report
    html_report = report_generator.generate_html_report(result)
    with open('compliance_report.html', 'w', encoding='utf-8') as f:
        f.write(html_report)
    
    # Generate text report
    text_report = report_generator.generate_text_report(result)
    with open('compliance_report.txt', 'w', encoding='utf-8') as f:
        f.write(text_report)
    
    # Generate JSON output
    json_output = {
        "part_number": result.part_number,
        "serial_number": result.serial_number,
        "purchase_order": result.purchase_order,
        "cert_type": result.cert_type,
        "status": result.status,
        "confidence_score": result.confidence_score,
        "flags": [asdict(flag) for flag in result.flags],
        "extracted_data": result.extracted_data,
        "generated_at": datetime.now().isoformat()
    }
    
    with open('compliance_result.json', 'w', encoding='utf-8') as f:
        json.dump(json_output, f, indent=2)
    
    # Print summary
    print("\n" + "="*60)
    print("COMPLIANCE VALIDATION COMPLETE")
    print("="*60)
    print(f"Part Number: {result.part_number}")
    print(f"Status: {result.status}")
    print(f"Issues Found: {len(result.flags)}")
    print(f"Confidence: {result.confidence_score:.2%}")
    print("\nReports generated:")
    print("- compliance_report.html (Human-readable HTML)")
    print("- compliance_report.txt (Plain text)")
    print("- compliance_result.json (JSON format)")
    
    if result.flags:
        print(f"\nTop Issues:")
        for flag in result.flags[:3]:  # Show first 3 issues
            print(f"- [{flag.severity}] {flag.issue}")

if __name__ == "__main__":
    main() 