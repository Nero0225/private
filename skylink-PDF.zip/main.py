from llama_cloud_services import LlamaParse
import os
from tenacity import retry, stop_after_attempt, wait_exponential
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Get API key from environment variable
API_KEY = os.getenv("LLAMA_CLOUD_API_KEY", "llx-VuNKq2WQxjlXckDxjDAnBOP4kiDC8dL1B97XIazC7eRlKts3")

@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=10),
    reraise=True
)
def parse_document(file_path: str) -> str:
    """Parse a document with retry logic on failure."""
    try:
        parser = LlamaParse(
            api_key=API_KEY,
            parse_mode="parse_page_with_llm",
            strict_mode_image_ocr=True,
            num_workers=4,
            verbose=True,
            language="en",
            timeout=60  # Add explicit timeout
        )
        
        # Parse document
        logger.info(f"Starting to parse document: {file_path}")
        result = parser.parse(file_path)
        
        # Get markdown output
        markdown_documents = result.get_markdown_documents(split_by_page=True)
        
        logger.info(f"Successfully parsed document: {file_path}")
        return markdown_documents
        
    except Exception as e:
        logger.error(f"Error parsing document {file_path}: {str(e)}")
        raise

if __name__ == "__main__":
    try:
        output = parse_document("./1.pdf")
        
        # Write output to file
        print(output)
        with open("output.md", "w", encoding="utf-8") as f:
            # Extract text content from the Document object
            for doc in output:
                f.write(doc.text)
                f.write("\n\n")  # Add separation between pages
            
        logger.info("Successfully wrote output to output.md")
        
    except Exception as e:
        logger.error(f"Failed to process document: {str(e)}")
        raise

# sync batch
# results = parser.parse(["./my_file1.pdf", "./my_file2.pdf"])

# # async
# result = await parser.aparse("./my_file.pdf")

# # async batch
# results = await parser.aparse(["./my_file1.pdf", "./my_file2.pdf"])