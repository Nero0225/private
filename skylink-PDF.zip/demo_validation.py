#!/usr/bin/env python3
"""
Demo script for Aerospace Compliance Validation System
Shows expected output without requiring OpenAI API key
"""

import json
from datetime import datetime
from compliance_validator import ValidationFlag, ComplianceResult, ReportGenerator

def create_demo_result():
    """Create a demo compliance result based on the actual output.md content"""
    
    # Simulate extracted data from the Boeing document
    extracted_data = {
        "part_numbers": ["MS20470AD4-5.5", "MS2047OAD4-5.5"],
        "purchase_orders": ["154748"],
        "serial_numbers": ["224019C462", "2240856908", "224086H001"],
        "certificates": [
            {
                "type": "Material Certification",
                "number": "2024GMLJOA",
                "date": "2024-07-30",
                "issuer": "Boeing Distribution Services Inc"
            },
            {
                "type": "Certificate of Conformity",
                "number": "A916604",
                "date": "2024-02-08",
                "issuer": "ATELIERS DE LA HAUTE-GARONNE"
            }
        ],
        "dates": {
            "manufacturing": "2024-01-19",
            "certification": "2024-02-08",
            "shipping": "2024-07-30"
        },
        "manufacturer": {
            "name": "AHG ATELIERS HAUTE-GARONNE",
            "cage_code": "F0095",
            "approval_number": "30030"
        },
        "specifications": ["NASM20470", "NASM5674", "AMS2T70", "MIL-DTL-5541"],
        "compliance_statements": [
            "Parts manufactured by AHG and delivered under this CoC are DFARS compliant per DFAR 252.225-7009",
            "Items are in conformity with all current governmental requirements"
        ],
        "traceability_chain": [
            "Boeing Distribution Services -> AHG Ateliers Haute-Garonne -> Material Producer",
            "Lot tracking through 224019C462",
            "Material heat number 62 1F2"
        ]
    }
    
    # Create validation flags based on analysis
    flags = [
        ValidationFlag(
            issue="Part number inconsistency found: MS20470AD4-5.5 vs MS2047OAD4-5.5",
            reference="QC Manual Section 2.3",
            severity="MEDIUM"
        ),
        ValidationFlag(
            issue="Missing explicit expiration date for Material Certification",
            reference="ASA Standard 21.302(b)",
            severity="HIGH"
        ),
        ValidationFlag(
            issue="Document contains multiple lot numbers - verify correct application",
            reference="QC Manual Section 4.1",
            severity="LOW"
        ),
        ValidationFlag(
            issue="Incomplete inspection documentation - missing dimensional inspection results",
            reference="QC Manual Section 7.3",
            severity="MEDIUM"
        )
    ]
    
    return ComplianceResult(
        part_number="MS20470AD4-5.5",
        serial_number="224019C462",
        purchase_order="154748", 
        cert_type="Material Certificate",
        status="SOFT_FAIL",
        flags=flags,
        extracted_data=extracted_data,
        confidence_score=0.82
    )

def main():
    """Run the demo validation"""
    print("🔬 Aerospace Compliance Validation System - DEMO MODE")
    print("=" * 60)
    print("📋 Analyzing Boeing Distribution Services trace document...")
    print("🤖 Simulating AI-powered analysis...")
    
    # Create demo result
    result = create_demo_result()
    
    # Generate reports
    report_generator = ReportGenerator()
    
    # Generate HTML report
    html_report = report_generator.generate_html_report(result)
    with open('demo_compliance_report.html', 'w', encoding='utf-8') as f:
        f.write(html_report)
    
    # Generate text report
    text_report = report_generator.generate_text_report(result)
    with open('demo_compliance_report.txt', 'w', encoding='utf-8') as f:
        f.write(text_report)
    
    # Generate JSON output
    json_output = {
        "part_number": result.part_number,
        "serial_number": result.serial_number,
        "purchase_order": result.purchase_order,
        "cert_type": result.cert_type,
        "status": result.status,
        "confidence_score": result.confidence_score,
        "flags": [{"issue": flag.issue, "reference": flag.reference, "severity": flag.severity} for flag in result.flags],
        "extracted_data": result.extracted_data,
        "generated_at": datetime.now().isoformat()
    }
    
    with open('demo_compliance_result.json', 'w', encoding='utf-8') as f:
        json.dump(json_output, f, indent=2)
    
    # Print summary
    print(f"\n✅ Demo validation completed!")
    print(f"📊 Analysis Results:")
    print(f"   • Part Number: {result.part_number}")
    print(f"   • Status: {result.status}")
    print(f"   • Issues Found: {len(result.flags)}")
    print(f"   • Confidence: {result.confidence_score:.1%}")
    
    print(f"\n📁 Demo reports generated:")
    print(f"   • demo_compliance_report.html")
    print(f"   • demo_compliance_report.txt") 
    print(f"   • demo_compliance_result.json")
    
    print(f"\n🔍 Key Findings:")
    for i, flag in enumerate(result.flags[:3], 1):
        print(f"   {i}. [{flag.severity}] {flag.issue}")
    
    print(f"\n💡 This demo shows what the system produces when analyzing")
    print(f"   aerospace trace documents with AI-powered validation.")
    print(f"   Set OPENAI_API_KEY to run real analysis!")

    # Show JSON output sample
    print(f"\n📄 Sample JSON Output:")
    print("=" * 40)
    sample_json = {
        "part_number": result.part_number,
        "status": result.status,
        "flags": [{"issue": flag.issue, "severity": flag.severity} for flag in result.flags[:2]]
    }
    print(json.dumps(sample_json, indent=2))

if __name__ == "__main__":
    main() 