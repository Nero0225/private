# Boeing Distribution Services Inc: CONSOLIDATION: SHB04130779

Tel: +1.305.925.2600 Fax: +1.305.507.7191

Website: BoeingDistribution.com

# CARTON LEVEL PACKING LIST

| Sold To:               | Ship To:              | Ultimate Destination:  |
| ---------------------- | --------------------- | ---------------------- |
| SKYLINK                | SKYLINK               | SKYLINK                |
| 2800 S FINANCIAL COURT | 2800 S FINANCIAL CT   | 2800 S FINANCIAL COURT |
| SANFORD FL 32773       | SANFORD FL 32773-8118 | SANFORD FL 32773       |
| US                     | US                    | US                     |

DATE: 07/30/24

SHIP VIA: UPS GRD COLL

TERMS: NET 30

SHIPPING TERMS: FCA-SELLER'S WHSE

| BOX NO          | DIMENSIONS | WEIGHT         |
| --------------- | ---------- | -------------- |
| CT0001912282144 | 12 X 9 X 1 | 1,7795 0.81 KG |

| CUSTOMER PO | PICK TICKET NO | PART NUMBER    | QTY SHIPPED | UOM |
| ----------- | -------------- | -------------- | ----------- | --- |
| 154748      | JF1R78.101     | MS204ZOAD4-5.5 | 2500        | EA  |

MATERIAL TO BE RETURNED MUST HAVE PRIOR AUTHORIZATION BY BOEING DISTRIBUTION SERVICES INC.

ALL ITEMS ARE SUBJECT TO A 100% RESTOCKING CHARGE.

BY RECEIVING DELIVERY OF THE ITEMS COVERED BY THIS PACKING SLIP, BUYER AGREES TO THE TERMS AND CONDITIONS OF SALE AT: https://www.boeingdistribution.com/aerol/conditions-sale/

# BOEING

INV: KXBPOM

# Boeing Distribution Services Inc

Tel: +1.305.925.2600 Fax: +1.305.507.7191 WWW.BoeingDistribution.com

PickTkt Number: JF1R78.101

Remit to Address: 88289 Expedite Way, Chicago, IL 60695-0001

Wire Instructions: Boeing Distribution Services INC. JPMorgan Chase Bank New York

Sold To:

Page 1 of 1

011341

# Ship To:

SKYLINK

2800 S FINANCIAL COURT

SANFORD, FL 32773

United States

714-546-8289

SANFORD, FL 32773-8118

United States

# Order No:

154748

# Date:

07/30/24

# Ship Via:

UPS GRD COLL

# Terms:

NET 30

# (Shipping Terms:

FCA-SELLER'S WHSE)

| Item No: | Quantity Ordered | Part Number and Description:                                                                                                                                                                                                                                                             | Unit: | (Shipped: |
| -------- | ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----- | --------- |
| 1        | 2500             | MS2O47OAD4-5.5 RIVET, SOLID ECCN EAR99 Tariff 7616.10.3000 Schedule B: 7616.10.3000 MFR AHG ATELIERS HAUTE-GARONNE Ctrl#: 2024GMIJOA Lot#: 224019C462 LotQty 2500 Country of Origin FR Rev#: 2 Cust PN: MS2O47OAD4-5.5 Cage Code: F0095 Net weight: 1.65 LB / 0.7 KG CTN: MKOO0012757335 | EA    | 2500      |

These items are controlled by the U.S. Government and authorized for export only to the country ultimate destination for use by the ultimate consignee or end-user(s) herein identified. They may not be resold, transferred, or otherwise disposed of, to any other country or to any person other than the authorized ultimate consignee or end-user(s); either in their original form or after being incorporated into other items, without first obtaining approval from the U.S. government or as otherwise authorized by U.S. law and regulations.

MATERIAL TO BE RETURNED MUST HAVE PRIOR AUTHORIZATION BY BOEING DISTRIBUTION SERVICES INC: ALL ITEMS ARE SUBJECT TO A 100% RESTOCKING CHARGE

SHIPPED FROM: 3760 W. 108TH ST DOOR B, MIAMI, FL 33018

MATERIAL CERTIFICATION: BOEING DISTRIBUTION SERVICES INC WARRANTS THAT THE ITEMS SUBJECT OF THIS INVOICE WILL BE FREE FROM DEFECTS OF MATERIAL AND WORKMANSHIP AND; AS SET FORTH ON THE MATERIAL CERTIFICATION FORM ACCOMPANYING THE ITEMS SUBJECT OF THIS INVOICE; ARE IN CONFORMITY WITH ALL CURRENT GOVERNMENTAL REQUIREMENTS AND THE SPECIFICATIONS OF THE RESPECTIVE MANUFACTURERS: BOEING DISTRIBUTION SERVICES DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING ALL WARRANTIES OF MERCHANTABILITY AND OF FITNESS FOR A PARTICULAR PURPOSE: THE LIABILITY OF BOEING DISTRIBUTION SERVICES IS EXPRESSLY LIMITED TO REPLACEMENT BECAUSE OF A DEFECT IN MATERIAL OR WORKMANSHIP; SUCH REPLACEMENT OF ANY ITEM WHICH IS REJECTED SHALL CONSTITUTE SATISFACTION OF ALL OBLIGATIONS BOEING DISTRIBUTION SERVICES MAY HAVE IN CONNECTION WITH SUCH ITEM WHETHER LIABILITY IS BASED UPON CONTRACT RIGHTS, NEGLIGENCE, OR OTHERWISE. FURTHER, BOEING DISTRIBUTION SERVICES SHALL NOT BE LIABLE FOR SPECIAL INDIRECT OR CONSEQUENTIAL DAMAGES. BOEING DISTRIBUTION SERVICES MUST BE NOTIFIED OF A REJECTION OF AN ITEM WITHIN 30 DAYS AFTER RECEIPT BY THE CUSTOMER.

# PACKING SLIP

Jennifer Russell
Supply Chain Quality Leader

BY RECEIVING DELIVERY OF THE ITEMS COVERED BY THIS PACKING SLIP, BUYER AGREES TO THE TERMS AND CONDITIONS OF SALE AT: FRON V.190205 https://www.boeingdistribution.com/aerolconditions-sale

# Boeing Distribution Services Inc.

PO. Box 025263 Miami, FL 33102-5263  Tel: 305.925.2600  Fax: 305.507.7191

Plant Location: 3760 W 108th Street Miami, FL 33018 SITA: MIAMMCR

www.BoeingDistribution.com

Shipped From: 3760 W. 108TH ST DOOR B, MIAMI, FL 33018

# Material Certification

The items set forth on the purchase order referred to below have been visually inspected and the dimensions thereof have been measured by US, and based on the aforesaid, as well as the representation made to us by the manufacturers of the items subject of such purchase order, we hereby certify that such items are in conformity with all current governmental and manufacturer's requirements, specifications, drawings, and conform to the purchase order requirements. Said items are in new condition and have not been obtained from any U.S. Government or Military source and are traceable to Boeing Distribution Services.

| FIRM:            | SKYLINK |
| ---------------- | ------- |
| PURCHASE ORDER#: | 154748  |

| LNP#   | QANTITY      | DJM PART NOMBER | COST REF#  | LOT- NMBER           | MANOFACTIRBR | CCODB | REV | EEf Date | EXPDATB |
| ------ | ------------ | --------------- | ---------- | -------------------- | ------------ | ----- | --- | -------- | ------- |
| 2500EA | M520470AD4-5 |                 | 224019C462 | AHG ATELIERS HAUTE-G | F0095        |       |     |          |         |

BDSI CTRL/LOT # :2024GMLJOA

Jennifer Rugsell

Supply Chain Quality Leader

Inv #RXBPOM 07/30/24

Form 217 Rev 1.0

# AHi ATELIERS DE LA HAUTE-GARONNE

Ets AURIOL & Cle - S.ASau capital de 13551918 EUR - ZL de FLOURENS BP 73103 26 route dc lasbordes 31130 FLOURENS Cedex (FRANCE)

Tel (331) 561 83 6035 Fax (33) 561 83 95 05 RCS TOULOUSE B 550 800 528 SIRET 550 800 528 00014 APE 25942

# PACKING SLIP

Ne 556758 of 21/06/2024

Supplier No: V1088-01

Account No: 3969

File No: UI 10

Represent: RACHEL +1(651) 585 85 Coface No

# Shipment to

BOEING DISTRIBUTION SERV.

3760 W. 108th STREET

DOCK DOOR B

HIALEAH GARDENS 33018

MIAMI 33102-5263

ETATS UNIS

Tel: 001 305 925 2600

Fax: 001 305 507 7191

# Ordered by

(Achat RAFAEL NUNE)

# Pre-carriage by

&gt;70KGS - Nadia Zaim@Boeingdistri

# Number of packaging

| Net weight   | 226.348 Kg |
| ------------ | ---------- |
| Gross weight | 236.918 Kg |

# ORDERED PART NUMBER

AIRCRAFT PARTS Manufactured by AHG - NATO: F0O95 Origin: FRANCE

Your PO.Nbr: OOVJ29712

Our Ackltem: 4480831 002 Part Completed

| Part Number                                | QTY SHIP      | SCHEDULED TO BE DELIV |
| ------------------------------------------ | ------------- | --------------------- |
| MS2OAZOAD4-S5-5                            | 499.000 Lb    | 15 JUL 2024           |
| 831921 Pcsm 2117-TANL3.1124-T4             | 794050 Pcst\* |                       |
| univ.head marked chamfer                   |               |                       |
| Optical Sorting NASM2O47O                  |               |                       |
| Your ref MS2O4ZOADA-5.5 Ill MSZOAZOAD4-5.5 |               |                       |

# Lot Information

| Lot nb     | Qty        | AHG ID Number    | Chemical coating |
| ---------- | ---------- | ---------------- | ---------------- |
| 224019C462 | 12.000 Lb  | 448083 PO02 FOO1 | gold             |
| 2240856908 | 284.000 Lb | 448083 POO2 FO02 | gold             |
| 224086H0O1 | 203.000 Lb | 448083 P0O2 FOQ3 |                  |


# ATELIERS DE LA HAUTE-GARONNE

Ets AURIOL & Cie - SAS au capital de 13551918 EUR ZL de FLOURENS BP 73103 26 route de Lasbordes 31130 FLOURENS Cedex (FRANCE)

Tel. (33) 561 83 60 35 - Fax (33) 561 83 95 05 RCS TOULOUSE 8 S50 800 528 SIRET 550 800 528 00014 APE 2594Z

# PACKING SLIP

Ng 556758 of 21/0602024 Pi 2

Account No 3969

File No Ui 10

| ORDERED               | PART NUMBER | QTY | SHIP. SCHEDULED | TO BE DELIV. |
| --------------------- | ----------- | --- | --------------- | ------------ |
| Chemical coating gold |             |     |                 |              |

Estimated quantity

Certificate of Conformity for each lot is available inside identified package

# ATELIERS DE LA HAUTE-GARONNE

Ets AURIOL &Cie - SAS au capital de 13551918 EUR Z de FLOURENS BP 73103 26 route de Lasbordes 31130 FLOURENS Cedex (FRANCE)

Tel (33) 561 83 60 35 - Fax (33) 561 83 95 05 RCS TOULOUSE B 550.800 528 SIRET 550 B00 528 00014 APE 25942

# CERTIFICATE of CONFORMITY

Of 08 FEB 2024

Le 13/02/2024 and Inspection Certificate No A916604

Your PO. nb OVJ297 ACCORDING TO NF L O-15C AND EN 0204 TYPE 3.1 Page 1/2

of 20 JUN 2023 Supplier number V108841

No ack 448083 of 20 JUN 2023

# Shipment to (or notify party)

BOEING (USD) DISTRIBUTION SERV:

3760 W: 108TH STREET DOCK DOOR B

HIALEAH GARDENS 33018

ETATS UNIS

# Ordered by

BOEING DISTRIBUTION SERV.INC

PO: BOX 026263 33102-6263 MIAMI ETATS UNIS

| TEM                                             | ORDERED                           | PART NUMBER            | SHIPPED               |
| ----------------------------------------------- | --------------------------------- | ---------------------- | --------------------- |
| 2                                               | 50.000 Lb                         | MS2OAZOAD4-5-5 (2)     | 12.000 Lb             |
|                                                 |                                   | NASM2O4ZO              |                       |
| Kour Item                                       | 2117-T4WL3.1124T4L86              | 18955 Pcs              |                       |
| Your ref                                        | MS2O4ZOAD4-5.5 III MS2OA7OAD4-5.5 |                        |                       |
| Technical spec                                  | NASM5674                          |                        |                       |
| Heat treat per                                  | NASMSSZ4AMS2T7O                   | Coating                | Chemical coating gold |
| Lot nb                                          | 224019C462                        | Qty:                   | 425.000 Lb            |
| AHG Wire lot nb.                                | Per                               | MIL-DTL-5541(F) tl c1A |                       |
|                                                 | 280232                            | Material heat nb       | 62 1F2                |
| CAGE Code:                                      | FC95                              | Origin:                | France                |
| AHG ID Number:                                  | 448083                            | PO.2                   | FCO1                  |
| Arbus QPL QUALIFIED / Manufacture heading date: | 19 JAN 2024                       | Material Producer      |                       |
| Coating date                                    | 27 JAN 2024                       |                        |                       |

# Shear at Room Temp

08-058MO double(D)simple(s): D Shear strength

| Mini    | Maxi    | Value   | Unit | Test |
| ------- | ------- | ------- | ---- | ---- |
| 26.0000 | 37.0000 | 34.7336 | KSI  | 3    |
| 26.0000 | 37.0000 | 34.2280 | KSI  |      |
| 26.0000 | 37.0000 | 35.0431 | KSI  |      |

This certificate shall not be reproduced, in part or in full, without the written permission of AHG. Any alteration, forgery or fraudulent report will be punishable by the French Law.

Item 2 to be continued

# AH ATELIERS DE LA HAUTE-GARONNE

Ets AURIOL & Cie - SASaucapital de 13 551 918 EUR - ZL de FLOURENS BP 73103 26 route de Lasbordes 31130 FLOURENS Cedex (FRANCE)

Tel (33) 561 83 60 35 - Fax (33) 561 83 9505 RCS TOULOUSE 8 550800 528 SIRET 550 800 528 00014 - APE 25947

# CERTIFICATE of CONFORMITY

of 0 FEB 2024

Le 13/02/2024 and Inspection Certificate No A916604 Page 21

ACCORDING TO NF LO-15C AND EN10204 TYPE 3.1

Your P.O. nb. COVJ297 of 20 JUN 2023 Supplier number V1oe8-01

N? ack 448083 of 20 JUN 2023

# ORDERED PART NUMBER

Item 2 Continuation MSZOA70AD4 6-5 (2)

| Mini                       | Max            | Value              | Uni    | Test  |
| -------------------------- | -------------- | ------------------ | ------ | ----- |
| 08-722MO                   | compliant: OIN | Nb defective parts | 0.0000 | Piece |
| dimensional inspection     | Compliant      | Test# 00z0         |        |       |
| Grain size 08-O4IMO        | Grain size     | 6.000              | 8.5000 |       |
| Marking 08-057MO           | Compliant      | Test# 0015         |        |       |
| MacroMMacrography 08-057MO | Compliant      | Test# 0015         |        |       |

| CR      | CU      | FE      | MG      | MN       | SI    | TI + ZR | ZN      | EA      |
| ------- | ------- | ------- | ------- | -------- | ----- | ------- | ------- | ------- |
| 0.02000 | 2.80000 | 0.41000 | 0.46000 | 0.150000 | 0.400 | 0.02000 | 0.13000 | BALANCE |

OUR AIRBUS SAS APPROVAL NUMBER IS 30030, of 31 August 2007

OUR BAE SYSTEMS APPROVAL LETTER REFERENCE IS ACOIALTIJJHI4OC6

This certificate shall not be reproduced; in part or in full; without the written permission of AHG

Any alteration, forgery or fraudulent report will be punishable by French Law:

Parts manufactured by AHG and delivered under this ColC are DFARS compliant per DFAR 252.225-7009

We hereby declare, subject to exceptions or concessions listed in this statement of conformity; that the listed supplies comply with the requirements and that, after completion and verification, they satisfy in every respect all specified requirements and applicable standards.

# SUPPLIER'S INSPECTION

06 FEB 2024 Estimated quantity

NAME AND FUNCTION

MICELI SYLVIE Chef Service Contrôle

TRUE COPY CERTIFICATION

# ######  ######  #####  ###

# #    # 1  # #     #    1

# ######    # #

# #    #          #####

# ######  ###### #  #

#####      ###

Printed by redback

